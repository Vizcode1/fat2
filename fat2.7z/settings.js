/*SUBSCRIBE MY YOUTUBE DIRRONE OFC*/
const fs = require("fs");
const {
   indonesia
} = require("./language");

// Website Api (jgn di ganti biar gk eror)
global.APIs = {
   alfa: 'https://api.zeeoneofc.my.id', //apabila link api eror, segera laporkan ke owner
}

//buy apikey premium 6285656631612
// Free apikey (silahkan login terus ganti Your Key dgn apikey lu)
global.APIKeys = {
   'https://api.zeeoneofc.my.id': 'ambil apikey di zeeone aja soalnya dirrone jga daftar di situ', // 👉 login https://api.zeeoneofc.my.id to get apikey
}

//language 
global.language = indonesia //change indonesia to english if you don't understand the language used by the bot

global.BOT_TOKEN = "6694711410:AAHu8aBZJMq2yqRQmLn3SIpNED2GUkXO2gA" //create bot here https://t.me/BotFather and get the bot token
global.BOT_NAME = "FATZX" //your bot name
global.OWNER_NAME = "fatzx team ddos" //your name
global.OWNER_NUMBER = "6283195477162" //your telegram number
global.OWNER = ["https://t.me/xxoxygen_1", "https://t.me/xxxoxygen"] // pastikan username sudah sesuai agar fitur khusus owner bisa di pakai
global.THUMBNAIL = "./image/DirroneOfc.jpg" // ini lol.jpg adalah nama foto di folder image. untuk foto bot
global.DONASI = "./image/donasi.jpg" // foto donasi di folder image
global.lang = language //don't change
