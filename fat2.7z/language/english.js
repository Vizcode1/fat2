/*SUBSCRIBE MY YOUTUBE DIRRONE OFC*/
exports.first_chat = "Hello"
